//! Day-2 commands: installed-host markers, MAC->IP bindings, status, and the Apache CGI callback.
use std::fs;
use std::path::Path;

use crate::config::{is_disk_name, is_hostname, is_image_name, is_mac, normalize_mac, Config, RootMode};
use crate::render;
use crate::util::{mkdir, now_iso, output, probe, run, run_soft, write_file, Ctx};

const LEASES: &str = "/var/lib/misc/dnsmasq.leases";

fn need_mac(arg: Option<&String>) -> Result<String, String> {
    let mac = normalize_mac(arg.ok_or("MAC address required")?);
    if is_mac(&mac) {
        Ok(mac)
    } else {
        Err(format!("invalid MAC: {mac}"))
    }
}

fn is_ip(s: &str) -> bool {
    s.parse::<std::net::Ipv4Addr>().is_ok()
}

/// Make the TFTP tree root-owned and read-only (no 777), except the marker dir the CGI (www-data) writes.
pub fn fix_perms(c: &Config, ctx: Ctx) -> Result<(), String> {
    let done = c.done_dir();
    mkdir(ctx, &done)?;
    let root = c.tftp_root.as_str();
    run(ctx, "find", &[root, "-path", &done, "-prune", "-o", "-exec", "chown", "root:root", "{}", "+"])?;
    run(ctx, "find", &[root, "-path", &done, "-prune", "-o", "-type", "d", "-exec", "chmod", "755", "{}", "+"])?;
    run(ctx, "find", &[root, "-path", &done, "-prune", "-o", "-type", "f", "-exec", "chmod", "644", "{}", "+"])?;
    run(ctx, "chown", &["www-data:www-data", &done])
}

/// Write our grub.cfg (it replaces the one shipped in the netboot tarball) and fix permissions.
pub fn write_grub(c: &Config, ctx: Ctx) -> Result<(), String> {
    write_file(ctx, &format!("{}/grub/grub.cfg", c.tftp_root), &render::grub_cfg(c), 0o644, false)?;
    fix_perms(c, ctx)
}

/// Create the "installed" marker for a MAC (grub.cfg skips PXE install for it).
pub fn mark_done(c: &Config, mac: &str) -> Result<(), String> {
    let dir = c.done_dir();
    fs::create_dir_all(&dir).map_err(|e| format!("mkdir {dir}: {e}"))?;
    let path = format!("{dir}/{mac}");
    fs::write(&path, format!("{}\n", now_iso())).map_err(|e| format!("write {path}: {e}"))
}

/// Prefix of every binding line in the hosts file (it is loaded with `conf-file=`).
const HOST_PREFIX: &str = "dhcp-host=";

/// Bindings as "mac,ip[,name]" (prefix stripped; comments/blank lines skipped; old unprefixed lines accepted).
fn read_hosts(c: &Config) -> Vec<String> {
    fs::read_to_string(&c.hosts_file)
        .map(|t| {
            t.lines()
                .map(|l| l.trim())
                .filter(|l| !l.is_empty() && !l.starts_with('#'))
                .map(|l| l.strip_prefix(HOST_PREFIX).unwrap_or(l).to_string())
                .collect()
        })
        .unwrap_or_default()
}

fn write_hosts(c: &Config, lines: &[String]) -> Result<(), String> {
    let tmp = format!("{}.tmp", c.hosts_file);
    let mut body = String::from("# managed by pxe-installer (pxe-ctl bind / unbind) - dnsmasq dhcp-host entries\n");
    for l in lines {
        body.push_str(HOST_PREFIX);
        body.push_str(l);
        body.push('\n');
    }
    if let Some(parent) = Path::new(&c.hosts_file).parent() {
        fs::create_dir_all(parent).map_err(|e| format!("mkdir {}: {e}", parent.display()))?;
    }
    fs::write(&tmp, body).map_err(|e| format!("write {tmp}: {e}"))?;
    fs::rename(&tmp, &c.hosts_file).map_err(|e| format!("rename {tmp}: {e}"))
}

fn reload_dnsmasq() {
    // dhcp-host lines in a conf-file are only read at startup (SIGHUP does not re-read them),
    // so restart. Leases are kept in dnsmasq's lease file and survive. No-op if not installed yet.
    run_soft(Ctx { dry: false }, "systemctl", &["restart", "dnsmasq"]);
}

/// Add or replace a binding (an existing line with the same MAC or IP is dropped first).
pub fn bind(c: &Config, mac: &str, ip: &str, name: &str, reload: bool) -> Result<(), String> {
    if !is_mac(mac) {
        return Err(format!("invalid MAC: {mac}"));
    }
    if !is_ip(ip) {
        return Err(format!("invalid IP: {ip}"));
    }
    if !name.is_empty() && !is_hostname(name) {
        return Err(format!("invalid hostname: {name} (use a-z, 0-9 and '-')"));
    }
    let mut lines: Vec<String> = read_hosts(c)
        .into_iter()
        .filter(|l| {
            let mut f = l.split(',');
            let m = f.next().unwrap_or("");
            let i = f.next().unwrap_or("");
            !(m.eq_ignore_ascii_case(mac) || i == ip)
        })
        .collect();
    lines.push(if name.is_empty() { format!("{mac},{ip}") } else { format!("{mac},{ip},{name}") });
    write_hosts(c, &lines)?;
    if reload {
        reload_dnsmasq();
    }
    println!("bound {mac} -> {ip}");
    Ok(())
}

fn unbind(c: &Config, key: &str) -> Result<(), String> {
    let key = normalize_mac(key);
    let lines: Vec<String> = read_hosts(c)
        .into_iter()
        .filter(|l| {
            let mut f = l.split(',');
            let m = f.next().unwrap_or("");
            let i = f.next().unwrap_or("");
            !(m == key || i == key)
        })
        .collect();
    write_hosts(c, &lines)?;
    reload_dnsmasq();
    println!("unbound {key}");
    Ok(())
}

fn list_done(c: &Config) -> Vec<(String, String)> {
    let mut v = Vec::new();
    if let Ok(rd) = fs::read_dir(c.done_dir()) {
        for e in rd.flatten() {
            let name = e.file_name().to_string_lossy().to_string();
            if is_mac(&name) {
                let when = fs::read_to_string(e.path()).unwrap_or_default().trim().to_string();
                v.push((name, when));
            }
        }
    }
    v.sort();
    v
}

fn status(c: &Config) {
    let installed = list_done(c);
    let hosts = read_hosts(c);
    // dnsmasq.leases: <expiry> <mac> <ip> <hostname> <client-id>
    let leases: Vec<Vec<String>> = fs::read_to_string(LEASES)
        .unwrap_or_default()
        .lines()
        .map(|l| l.split_whitespace().map(|s| s.to_string()).collect::<Vec<_>>())
        .filter(|f| f.len() >= 4)
        .collect();

    let mut macs: Vec<String> = installed.iter().map(|(m, _)| m.clone()).collect();
    for l in &hosts {
        macs.push(l.split(',').next().unwrap_or("").to_lowercase());
    }
    for f in &leases {
        macs.push(f[1].to_lowercase());
    }
    macs.retain(|m| is_mac(m));
    macs.sort();
    macs.dedup();

    println!("{:<18} {:<16} {:<16} {:<10} {}", "MAC", "BOUND IP", "LEASE IP", "STATE", "INSTALLED AT");
    for mac in &macs {
        let bound = hosts
            .iter()
            .find(|l| l.split(',').next().map(|m| m.eq_ignore_ascii_case(mac)).unwrap_or(false))
            .and_then(|l| l.split(',').nth(1))
            .unwrap_or("-");
        let lease = leases.iter().find(|f| f[1].eq_ignore_ascii_case(mac)).map(|f| f[2].as_str()).unwrap_or("-");
        let done = installed.iter().find(|(m, _)| m == mac);
        let state = if done.is_some() {
            "installed"
        } else if lease != "-" {
            "pending"
        } else {
            "waiting"
        };
        println!("{:<18} {:<16} {:<16} {:<10} {}", mac, bound, lease, state, done.map(|d| d.1.as_str()).unwrap_or(""));
    }
    println!("\nstate: installed = marker present (PXE skips it) | pending = has a DHCP lease, no done callback yet | waiting = bound, never seen");
}

/// `ctl mode [tmpfs|nfs]` - show or switch the PXE deploy way. The switch is applied at once: the runtime
/// config is updated, grub.cfg is rewritten and the NFS exports are adjusted (the live root is only
/// exported in nfs mode). Hosts that are already booted into Clonezilla are not affected; the next PXE
/// boot uses the new way. No service restart is needed.
fn switch_mode(mut c: Config, wanted: Option<&str>) -> Result<(), String> {
    let Some(wanted) = wanted else {
        println!("PXE deploy way: {}", c.root_mode.as_str());
        return Ok(());
    };
    c.set("ROOT_MODE", wanted)?;
    let ctx = Ctx { dry: false };
    write_file(ctx, crate::config::RUNTIME_CONF, &c.runtime_conf(), 0o644, false)?;
    write_grub(&c, ctx)?;
    crate::install::setup_nfs(&c, ctx)?;
    println!(
        "PXE deploy way is now: {} ({})",
        c.root_mode.as_str(),
        match c.root_mode {
            RootMode::Tmpfs => "the live system is downloaded over HTTP into the target's RAM",
            RootMode::Nfs => "the target mounts the live system from the server over NFS",
        }
    );
    crate::install::report_missing(&c);
    Ok(())
}

/// `ocs-sr` saves images under this folder (Clonezilla's default `ocsroot`), so IMAGE_DIR has to be it.
const OCS_ROOT: &str = "/home/partimag";
/// Only one capture at a time (the GUI button could be clicked twice). /run is a tmpfs: gone after a reboot.
const CLONE_LOCK: &str = "/run/pxe-installer-clone.lock";

/// Arguments of `ctl clone`: (disk name without /dev/, --yes, --force).
fn parse_clone_args(args: &[String]) -> Result<(String, bool, bool), String> {
    let mut disk: Option<String> = None;
    let (mut yes, mut force) = (false, false);
    for a in args {
        match a.as_str() {
            "--yes" => yes = true,
            "--force" => force = true,
            d if !d.starts_with('-') && disk.is_none() => disk = Some(d.trim_start_matches("/dev/").to_string()),
            other => return Err(format!("unexpected argument '{other}'")),
        }
    }
    let disk = disk.ok_or("disk name required, e.g.: pxe-ctl clone nvme0n2 [--yes] [--force]")?;
    if !is_disk_name(&disk) {
        return Err(format!("'{disk}' is not a disk name (use e.g. sda or nvme0n2, lowercase letters and digits)"));
    }
    Ok((disk, yes, force))
}

/// Removes the clone lock when the capture ends (or fails).
struct CloneLock;
impl Drop for CloneLock {
    fn drop(&mut self) {
        let _ = fs::remove_file(CLONE_LOCK);
    }
}

/// `ctl clone <disk> [--yes] [--force]` - capture <disk> of THIS host into the Clonezilla image repository as
/// IMAGE_NAME (`ocs-sr savedisk`, partclone + parallel zstd) and re-export the repository over NFS, so the
/// targets can restore it. The disk is only read, but it must be idle: not mounted, no swap, not in use.
/// `--yes` runs without the confirmation prompt (the GUI has no terminal for it); `--force` deletes an
/// existing image of the same name first (without it that is an error).
fn clone_image(c: Config, args: &[String]) -> Result<(), String> {
    let (disk, yes, force) = parse_clone_args(args)?;
    if !is_image_name(&c.image_name) {
        return Err(format!("IMAGE_NAME '{}' is not valid", c.image_name));
    }
    if c.image_dir != OCS_ROOT {
        return Err(format!(
            "IMAGE_DIR is {} but ocs-sr saves images under {OCS_ROOT}: set IMAGE_DIR={OCS_ROOT} (or make {OCS_ROOT} a bind mount of it) and re-run start",
            c.image_dir
        ));
    }
    if !probe("sh", &["-c", "command -v ocs-sr >/dev/null"]) {
        return Err("ocs-sr not found: install the Clonezilla tools first (pxe-installer install)".into());
    }

    // the source must be a whole disk and idle (lsblk lists the mount points of its partitions/LVM children too)
    let dev = format!("/dev/{disk}");
    let kind = output("lsblk", &["-dno", "TYPE", &dev]).map_err(|_| format!("{dev} is not a block device"))?;
    if kind != "disk" {
        return Err(format!("{dev} is a '{kind}', not a whole disk (use e.g. sda, not sda1)"));
    }
    let used = output("lsblk", &["-nro", "MOUNTPOINTS", &dev])
        .or_else(|_| output("lsblk", &["-nro", "MOUNTPOINT", &dev]))
        .map_err(|e| format!("cannot check whether {dev} is in use: {e}"))?;
    let used: Vec<&str> = used.lines().map(|l| l.trim()).filter(|l| !l.is_empty()).collect();
    if !used.is_empty() {
        return Err(format!(
            "{dev} is in use ({}): it must be unmounted and not hold swap; boot Clonezilla Live to image an OS disk that is running",
            used.join(", ")
        ));
    }

    // take the lock BEFORE touching the image: a second click must not delete what the first one is writing
    let _lock = fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(CLONE_LOCK)
        .map(|_| CloneLock)
        .map_err(|_| format!("another clone is running (or a stale lock: remove {CLONE_LOCK} if none is)"))?;

    let image = format!("{}/{}", c.image_dir, c.image_name);
    if Path::new(&image).exists() {
        if !force {
            return Err(format!(
                "image {image} already exists: delete it first (sudo rm -rf {image}) or use --force / the \"Overwrite\" box"
            ));
        }
        fs::remove_dir_all(&image).map_err(|e| format!("remove old image {image}: {e}"))?;
        println!("removed the old image {image}");
    }

    println!("Capturing {dev} as image {} (this takes a while, depending on the used data)", c.image_name);
    let confirm = if yes { "-batch" } else { "-c" };
    run(
        Ctx { dry: false },
        "ocs-sr",
        &["-q2", confirm, "-j2", "-z9p", "-sfsck", "-senc", "-p", "true", "savedisk", &c.image_name, &disk],
    )?;

    // make the new image visible to the targets
    crate::install::setup_nfs(&c, Ctx { dry: false })?;
    println!("Image {image} captured and exported over NFS ({}).", c.image_dir);
    crate::install::report_missing(&c);
    Ok(())
}

/// `pxe-installer ctl <subcommand> ...`
pub fn ctl(args: &[String]) -> Result<(), String> {
    let c = Config::load_runtime();
    match args.first().map(|s| s.as_str()) {
        Some("list") => {
            for (mac, when) in list_done(&c) {
                println!("{mac}  {when}");
            }
            Ok(())
        }
        Some("status") => {
            status(&c);
            Ok(())
        }
        Some("reinstall") => {
            let mac = need_mac(args.get(1))?;
            let path = format!("{}/{mac}", c.done_dir());
            match fs::remove_file(&path) {
                Ok(()) => println!("removed {path}"),
                Err(e) => println!("no marker for {mac} ({e})"),
            }
            Ok(())
        }
        Some("done") => {
            let mac = need_mac(args.get(1))?;
            mark_done(&c, &mac)?;
            // the CGI runs as www-data; keep the marker removable/readable by root and tftp
            println!("marked {mac} as installed");
            Ok(())
        }
        Some("stop") => {
            // stop the PXE services (DHCP/TFTP + HTTP); they stay enabled and come back on reboot
            run(Ctx { dry: false }, "systemctl", &["stop", "dnsmasq", "apache2", "nfs-server"])?;
            for svc in ["dnsmasq", "apache2", "nfs-server"] {
                println!("{svc}: {}", if service_active(svc) { "STILL ACTIVE" } else { "stopped" });
            }
            println!("PXE server stopped. Start it again with the Start button or: sudo systemctl start dnsmasq apache2");
            Ok(())
        }
        Some("grub") => {
            // run after copying netboot files into the TFTP root (the tarball ships its own grub.cfg)
            write_grub(&c, Ctx { dry: false })?;
            println!("wrote {}/grub/grub.cfg and fixed permissions", c.tftp_root);
            Ok(())
        }
        Some("nfs") => {
            // run after adding or changing a Clonezilla image: (re-)export the image repository
            crate::install::setup_nfs(&c, Ctx { dry: false })?;
            println!("Clonezilla image repository {} exported read-only (image: {})", c.image_dir, c.image_name);
            crate::install::report_missing(&c);
            Ok(())
        }
        Some("mode") => switch_mode(c, args.get(1).map(|s| s.as_str())),
        Some("clone") => clone_image(c, &args[1..]),
        Some("binds") => {
            for l in read_hosts(&c) {
                println!("{HOST_PREFIX}{l}");
            }
            Ok(())
        }
        Some("bind") => {
            let mac = need_mac(args.get(1))?;
            let ip = args.get(2).ok_or("IP required")?;
            let name = args.get(3).map(|s| s.as_str()).unwrap_or("");
            bind(&c, &mac, ip, name, true)
        }
        Some("unbind") => unbind(&c, args.get(1).ok_or("MAC or IP required")?),
        _ => Err("usage: pxe-installer ctl list | status | stop | grub | nfs | mode [tmpfs|nfs] | clone <disk> [--yes] [--force] | reinstall <mac> | done <mac> | binds | bind <mac> <ip> [name] | unbind <mac|ip>".into()),
    }
}

/// `pxe-installer cgi-done` - run by Apache as www-data via /usr/lib/cgi-bin/pxe-done.
pub fn cgi_done() -> Result<(), String> {
    let c = Config::load_runtime();
    let query = std::env::var("QUERY_STRING").unwrap_or_default();
    let mac = query.strip_prefix("mac=").map(normalize_mac).unwrap_or_default();
    if !is_mac(&mac) {
        print!("Status: 400 Bad Request\r\nContent-Type: text/plain\r\n\r\nbad mac\n");
        return Ok(());
    }
    match mark_done(&c, &mac) {
        Ok(()) => print!("Content-Type: text/plain\r\n\r\nok {mac}\n"),
        Err(e) => print!("Status: 500 Internal Server Error\r\nContent-Type: text/plain\r\n\r\n{e}\n"),
    }
    Ok(())
}

/// Hostname bound to this MAC (third field of its binding), if any and valid.
fn hostname_for(c: &Config, mac: &str) -> Option<String> {
    for l in read_hosts(c) {
        let mut f = l.split(',');
        if f.next().map(|m| m.eq_ignore_ascii_case(mac)).unwrap_or(false) {
            let _ip = f.next();
            let name = f.next().unwrap_or("").trim().to_string();
            if is_hostname(&name) {
                return Some(name);
            }
        }
    }
    None
}

fn cgi_error(status: &str, msg: &str) {
    print!("Status: {status}\r\nContent-Type: text/plain\r\n\r\n{msg}\n");
}

/// `pxe-installer cgi-seed` - Apache CGI at /cgi-bin/pxe-seed/<mac>/post.sh.
/// After restoring the Clonezilla image, the target fetches this script (grub.cfg passes its own MAC) and
/// runs it: it gives the clone the hostname bound to its MAC (MACs without a binding get the default
/// hostname), regenerates its machine-id / SSH host keys and calls pxe-done.
pub fn cgi_seed() -> Result<(), String> {
    let c = Config::load_runtime();
    let path = std::env::var("PATH_INFO").unwrap_or_default();
    let parts: Vec<&str> = path.trim_matches('/').split('/').collect();
    if parts.len() != 2 {
        cgi_error("404 Not Found", "expected /<mac>/post.sh");
        return Ok(());
    }
    let mac = normalize_mac(parts[0]);
    if !is_mac(&mac) {
        cgi_error("400 Bad Request", "bad mac");
        return Ok(());
    }
    match parts[1] {
        "post.sh" => {
            // these values are substituted into a root shell script: refuse anything but plain names
            let host = hostname_for(&c, &mac).unwrap_or_else(|| c.target_hostname.clone());
            if !is_hostname(&host) || !is_disk_name(&c.target_disk) {
                cgi_error("500 Internal Server Error", "invalid hostname or target disk in /etc/pxe-installer.conf");
                return Ok(());
            }
            print!("Content-Type: text/plain\r\n\r\n{}", render::post_script(&c, &host, &mac));
        }
        _ => cgi_error("404 Not Found", "unknown file"),
    }
    Ok(())
}

/// Used by `install` to check a service is up.
pub fn service_active(name: &str) -> bool {
    probe("systemctl", &["is-active", "--quiet", name])
}

#[cfg(test)]
mod tests {
    use super::*;

    fn tmp_cfg(tag: &str) -> Config {
        let dir = std::env::temp_dir().join(format!("pxe-test-{tag}-{}", std::process::id()));
        let _ = fs::create_dir_all(&dir);
        let mut c = Config::default();
        c.hosts_file = dir.join("hosts").to_string_lossy().to_string();
        c.tftp_root = dir.to_string_lossy().to_string();
        c
    }

    #[test]
    fn bind_replaces_same_mac_or_ip() {
        let c = tmp_cfg("bind");
        bind(&c, "aa:bb:cc:dd:ee:01", "192.168.5.11", "n1", false).unwrap();
        bind(&c, "aa:bb:cc:dd:ee:02", "192.168.5.12", "", false).unwrap();
        bind(&c, "aa:bb:cc:dd:ee:01", "192.168.5.13", "n1", false).unwrap(); // same MAC
        bind(&c, "aa:bb:cc:dd:ee:03", "192.168.5.12", "", false).unwrap(); // same IP as :02
        let l = read_hosts(&c);
        assert_eq!(l, vec!["aa:bb:cc:dd:ee:01,192.168.5.13,n1", "aa:bb:cc:dd:ee:03,192.168.5.12"]);
    }

    #[test]
    fn bind_rejects_bad_input() {
        let c = tmp_cfg("bad");
        assert!(bind(&c, "nope", "192.168.5.11", "", false).is_err());
        assert!(bind(&c, "aa:bb:cc:dd:ee:01", "300.1.1.1", "", false).is_err());
    }

    #[test]
    fn hostname_lookup_from_binding() {
        let c = tmp_cfg("hn");
        bind(&c, "aa:bb:cc:dd:ee:01", "192.168.5.11", "node01", false).unwrap();
        bind(&c, "aa:bb:cc:dd:ee:02", "192.168.5.12", "", false).unwrap();
        assert_eq!(hostname_for(&c, "aa:bb:cc:dd:ee:01"), Some("node01".to_string()));
        assert_eq!(hostname_for(&c, "aa:bb:cc:dd:ee:02"), None);
        assert_eq!(hostname_for(&c, "aa:bb:cc:dd:ee:09"), None);
        assert!(bind(&c, "aa:bb:cc:dd:ee:03", "192.168.5.13", "Bad_Name", false).is_err());
    }

    #[test]
    fn mode_switch_rejects_unknown_way() {
        // validated before anything is written (the real switch needs root and the PXE server)
        let mut c = Config::default();
        assert!(c.set("ROOT_MODE", "bogus").is_err());
        assert_eq!(c.root_mode, RootMode::Tmpfs);
        assert!(switch_mode(c.clone(), Some("bogus")).is_err());
        assert!(switch_mode(c, None).is_ok()); // just prints the current way
    }

    #[test]
    fn clone_args() {
        let a = |v: &[&str]| v.iter().map(|s| s.to_string()).collect::<Vec<String>>();
        assert_eq!(parse_clone_args(&a(&["sda"])).unwrap(), ("sda".to_string(), false, false));
        assert_eq!(parse_clone_args(&a(&["/dev/nvme0n2", "--yes", "--force"])).unwrap(), ("nvme0n2".to_string(), true, true));
        assert_eq!(parse_clone_args(&a(&["--yes", "sdb"])).unwrap().0, "sdb");
        assert!(parse_clone_args(&a(&[])).is_err()); // no disk
        assert!(parse_clone_args(&a(&["--yes"])).is_err());
        assert!(parse_clone_args(&a(&["sda; reboot"])).is_err()); // not a disk name
        assert!(parse_clone_args(&a(&["sda", "sdb"])).is_err()); // two disks
        assert!(parse_clone_args(&a(&["sda", "--bogus"])).is_err());
        assert!(parse_clone_args(&a(&["Sda"])).is_err());
    }

    #[test]
    fn marker_roundtrip() {
        let c = tmp_cfg("mark");
        mark_done(&c, "aa:bb:cc:dd:ee:01").unwrap();
        assert_eq!(list_done(&c).len(), 1);
    }
}
